using Microsoft.EntityFrameworkCore;
using guitar_shop.Data;
using guitar_shop.Models;
using System.Text.Json;

namespace guitar_shop.Services;

public class DbInitializer
{
    public static void Initialize(IServiceProvider serviceProvider)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        
        context.Database.EnsureCreated();
        
        if (!context.Guitars.Any())
        {
            var jsonPath = Path.Combine(Directory.GetCurrentDirectory(), "Data", "guitars.json");
            
            if (File.Exists(jsonPath))
            {
                var jsonData = File.ReadAllText(jsonPath);
                var guitars = JsonSerializer.Deserialize<List<Guitar>>(jsonData);
                
                if (guitars != null && guitars.Any())
                {
                    context.Guitars.AddRange(guitars);
                    context.SaveChanges();
                }
            }
        }
    }
}