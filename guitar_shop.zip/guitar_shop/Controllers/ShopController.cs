using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using guitar_shop.Data;
using guitar_shop.Models;

namespace guitar_shop.Controllers;

public class ShopController : Controller
{
    private readonly AppDbContext _db;
    
    public ShopController(AppDbContext db)
    {
        _db = db;
    }

    public async Task<IActionResult> Index(string search, string category, string color, decimal minPrice = 0, decimal maxPrice = 5000)
    {
        var guitars = await _db.Guitars.ToListAsync();
        
        if (!string.IsNullOrWhiteSpace(search))
            guitars = guitars.Where(g => g.Name.Contains(search, StringComparison.OrdinalIgnoreCase)).ToList();
        
        if (!string.IsNullOrWhiteSpace(category) && category != "Все")
            guitars = guitars.Where(g => g.Category == category).ToList();
            
        if (!string.IsNullOrWhiteSpace(color) && color != "Все")
            guitars = guitars.Where(g => g.Color == color).ToList();

        guitars = guitars.Where(g => g.Price >= minPrice && g.Price <= maxPrice).ToList();

        ViewData["Title"] = "Каталог";
        
        if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
        {
            return PartialView("_ProductsPartial", guitars);
        }
        
        return View(guitars);
    }
    
    [HttpPost]
    public async Task<IActionResult> Search(string search)
    {
        var guitars = await _db.Guitars.ToListAsync();
        
        if (!string.IsNullOrWhiteSpace(search))
            guitars = guitars.Where(g => g.Name.Contains(search, StringComparison.OrdinalIgnoreCase)).ToList();
        
        return PartialView("_ProductsPartial", guitars);
    }
}