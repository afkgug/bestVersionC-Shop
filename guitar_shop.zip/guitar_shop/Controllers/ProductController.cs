using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using guitar_shop.Data;
using guitar_shop.Models;

namespace guitar_shop.Controllers;

public class ProductController : Controller
{
    private readonly AppDbContext _db;
    
    public ProductController(AppDbContext db)
    {
        _db = db;
    }

    public async Task<IActionResult> Index(int id)
    {
        var guitar = await _db.Guitars.FindAsync(id);
        if (guitar == null) return NotFound();
        ViewData["Title"] = guitar.Name;
        
        ViewData["ReturnUrl"] = Request.Path;
        
        return View(guitar);
    }
}